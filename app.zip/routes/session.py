from fastapi import APIRouter
from app.services.session_manager import add_response, get_session
from app.services.evaluation import evaluate_answer

router = APIRouter()

@router.post("/submit-answer")
def submit(data: dict):
    session_id = data.get("session_id")
    question = data.get("question")
    answer = data.get("answer")

    session = get_session(session_id)

    # ✅ Fix 1: Check session exists
    if not session:
        return {"error": "Invalid session ID"}

    result = evaluate_answer(question, answer)

    add_response(session_id, answer, result["score"])

    return {
        "evaluation": result
    }
@router.get("/final-result/{session_id}")
def final_result(session_id: str):
    session = get_session(session_id)

    total_score = sum(session["scores"])
    max_score = len(session["scores"]) * 3

    percentage = (total_score / max_score) * 100

    decision = "Selected" if percentage >= 50 else "Rejected"

    return {
        "total_score": total_score,
        "percentage": percentage,
        "decision": decision
    }