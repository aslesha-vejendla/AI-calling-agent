from app.services.question_generator import generate_questions
from fastapi import APIRouter, UploadFile, File
import shutil
from app.services.resume_parser import extract_text
from app.services.ai_services import analyze_resume
from app.services.session_manager import create_session

router = APIRouter()

@router.post("/upload-resume")
async def upload_resume(file: UploadFile = File(...)):
    file_path = f"temp_{file.filename}"

    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    text = extract_text(file_path)

    structured = analyze_resume(text)

    questions = generate_questions(
        structured["skills"],
        structured["experience_level"]
    )

    # ✅ CREATE SESSION
    session_id = create_session(questions)

    # ✅ RETURN SESSION ID
    return {
        "message": "Interview started",
        "session_id": session_id,
        "profile": structured,
        "questions": questions
    }