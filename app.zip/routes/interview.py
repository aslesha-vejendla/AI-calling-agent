from fastapi import APIRouter
from app.services.evaluation import evaluate_answer
from app.models.schemas import AnswerRequest

router = APIRouter()
@router.post("/evaluate-answer")
def evaluate(data: AnswerRequest):
    result = evaluate_answer(data.question, data.answer)

    return {
        "question": data.question,
        "answer": data.answer,
        "evaluation": result
    }