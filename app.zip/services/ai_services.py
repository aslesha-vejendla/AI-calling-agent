import re

def analyze_resume(text):
    text_lower = text.lower()

    skills_db = [
        "python", "sql", "excel", "power bi", "pandas", "numpy",
        "machine learning", "data analysis"
    ]

    found_skills = [s for s in skills_db if s in text_lower]

    # crude experience guess
    experience = "Beginner"
    if "intern" in text_lower or "project" in text_lower:
        experience = "Intermediate"

    domain = "Data Science" if any(s in text_lower for s in ["data", "analysis"]) else "General"

    return {
        "skills": list(set(found_skills)),
        "experience_level": experience,
        "domain": domain
    }