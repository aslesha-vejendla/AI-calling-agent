sessions = {}

def create_session(questions):
    session_id = str(len(sessions) + 1)

    sessions[session_id] = {
        "questions": questions,
        "answers": [],
        "scores": []
    }

    return session_id


def add_response(session_id, answer, score):
    if session_id not in sessions:
        return

    sessions[session_id]["answers"].append(answer)
    sessions[session_id]["scores"].append(score)

def get_session(session_id):
    return sessions.get(session_id)