def evaluate_answer(question, answer):
    answer = (answer or "").lower()

    # simple keyword mapping per question type
    keyword_map = {
        "python": ["list", "tuple", "dictionary", "variable"],
        "sql": ["join", "where", "table", "query"],
        "power bi": ["dashboard", "visualization", "report"],
        "pandas": ["dataframe", "series", "missing"],
        "numpy": ["array", "matrix"],
        "data analysis": ["eda", "cleaning", "analysis"],
        "excel": ["pivot", "formula", "lookup"]
    }

    score = 0

    score = 0

    for key, words in keyword_map.items():
        if key in question.lower():
            matches = sum(1 for w in words if w in answer)

            if matches >= 2:
                score = 3
            elif matches == 1:
                score = 2
            else:
                score = 1
        

    # normalize score
    if score >= 3:
        rating = "Good"
    elif score == 2:
        rating = "Average"
    else:
        rating = "Poor"

    return {
        "score": score,
        "rating": rating
    }