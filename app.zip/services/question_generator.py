def generate_questions(skills, experience_level):
    question_bank = {
        "python": [
            "What are Python data types?",
            "Explain list vs tuple.",
            "What is a dictionary in Python?"
        ],
        "sql": [
            "What is a JOIN in SQL?",
            "Difference between WHERE and HAVING?",
            "What are primary keys?"
        ],
        "power bi": [
            "What is Power BI used for?",
            "Explain dashboards in Power BI.",
            "What is DAX?"
        ],
        "excel": [
            "What are pivot tables?",
            "Explain VLOOKUP.",
            "What is conditional formatting?"
        ],
        "pandas": [
            "What is a DataFrame in pandas?",
            "How do you handle missing values in pandas?"
        ],
        "numpy": [
            "What is NumPy used for?",
            "Difference between list and NumPy array?"
        ],
        "data analysis": [
            "What is EDA?",
            "Steps in a data analysis project?"
        ]
    }

    questions = []

    # collect questions
    for skill in skills:
        if skill in question_bank:
            questions.append(question_bank[skill][0])

    # adjust based on experience
    if experience_level == "Beginner":
        return questions[:3]
    elif experience_level == "Intermediate":
        return questions[:3]
    else:
        return questions[:3]