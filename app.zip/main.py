from fastapi import FastAPI
from app.routes import resume
from app.routes import interview
from app.routes import session

app = FastAPI()
app.include_router(session.router)
app.include_router(interview.router)
app.include_router(resume.router)

@app.get("/")
def root():
    return {"message": "Interview Agent Running"}